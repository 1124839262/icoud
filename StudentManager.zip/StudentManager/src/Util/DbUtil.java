package Util;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
/**
 * 数据库；连接测试
 * @author rednoob
 *
 */
public class DbUtil {
	private String dbUrl = "jdbc:mysql://localhost:3306/studentmanager?useUnicode=true&characterEncoding=utf8";
	private String dbUser = "root";
	private String dbPassword = "123123";
	private String jdbcName = "com.mysql.jdbc.Driver";
	private Connection connection = null;
	public Connection getConnection(){
		try {
			Class.forName(jdbcName);
			connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			System.out.println("数据库连接成功");
		} catch (Exception e) {
			System.out.println("数据库连接失败");
			e.printStackTrace();
		}
		return connection;
	}
	
	public void closeCon(){
		if(connection != null)
			try {
				connection.close();
				System.out.println("数据库连接关闭");
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	public static void main(String[] args) {
		DbUtil dbUtil = new DbUtil();
		dbUtil.getConnection();
	}
}
