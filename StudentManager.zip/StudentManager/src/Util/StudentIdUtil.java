package Util;

/**
 * 学号生成插件
 * @author rednoob
 *
 */
public class StudentIdUtil {
	public static String generateNum(int clazzId) {
		String sn= "";
		//sn=DateFormatUtil.getFormatDate(new Date(), "yyyyMMdd");
		sn=""+clazzId+System.currentTimeMillis();
		return sn;
	}
}
